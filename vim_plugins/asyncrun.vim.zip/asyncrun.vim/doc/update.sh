#! /bin/sh
~/github/vim-tools/html2vimdoc/bin/python ~/github/vim-tools/html2vimdoc.py -f asyncrun asyncrun.md > asyncrun.txt
