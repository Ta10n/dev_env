#include <iostream>

class Foo {
    public:
        int bar;
};

int main(int argc, char* argv[]) {
    Foo foo;
    foo.
    return 0;
}
