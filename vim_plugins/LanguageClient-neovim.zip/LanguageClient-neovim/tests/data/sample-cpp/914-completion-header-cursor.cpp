#include <string>
auto main() -> int
{
    auto foo = std::make
}
