#include <std

int main() {
    return 0;
}
