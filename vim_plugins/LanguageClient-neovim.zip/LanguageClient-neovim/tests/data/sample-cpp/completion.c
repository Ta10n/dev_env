struct Point {
	int x;
};

int main() {
	struct Point point;
    point.
}
