int main() {
    int rc = 0;

    if (rc == 0) {
    }

    return rc;
}
