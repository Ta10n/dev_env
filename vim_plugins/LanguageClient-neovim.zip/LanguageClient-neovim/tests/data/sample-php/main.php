<?php

function greet($name) {
    return "Yo, " + $name;
}

gr

?>
